#### Sistem Pencatatan Review Kematian Balita

**Contributors**  : 
1. Pacu Putra
2. Firly


> $ npm install

> $ npm init

> $ npm i axios

> $ npm i bcrypt

> $ npm i body-parser

> $ npm i dotenv

> $ npm i express

> $ npm i express-session

> $ npm i moment

> $ npm i moment-timezone

> $ npm i mysql

> $ npm i nodemon

> $ npm start

Open your browser

> http://localhost:5024